# SHTRANES.PRW

**Transferência automática de produtos com estoque excedente**

### **Dados da Customização**

----

Analista: Jonathan Torioni

----

### **Objetivo**

----

Inclusão de novos parâmetros para controlar a emissão dos pedidos de transferência. Este controle é necessário para a fase de implantação da rotina, permitindo efetuar transferências de produtos, linhas e marcas específicas e sem comprometer a capacidade de vazão da logística.

----

### **Parâmetros**

----

* **ES_TRANMAR** - Marca dos produtos transferência automática
* **ES_TRANLIN** - Linhas dos produtos para transferência automática
* **ES_TRANPRD** - Produtos para transferência automática
* 
Os parâmetros devem ser por filial e criados para todas as filias. Seu conteúdo deve ser inicialmente vazio e quando preenchido, separar os produtos, marcas e linhas com o PIPE.


----